#if !defined(AFX_X64LOGINDLG_H__155CDC5E_D432_4FE2_9BE8_65B2F4BCF7FF__INCLUDED_)
#define AFX_X64LOGINDLG_H__155CDC5E_D432_4FE2_9BE8_65B2F4BCF7FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// X64loginDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CX64loginDlg dialog
#include "afxwin.h"
#include "afxcmn.h"
class CX64loginDlg : public CDialog
{
// Construction
public:
	CX64loginDlg(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CX64loginDlg)
	enum { IDD = IDD_X64LOGIN_DIALOG };
	CStatic	m_ServerGG;
	CTabCtrl	m_Login_Tab;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CX64loginDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
HICON m_hIcon;
void StarTab();
	// Generated message map functions
	//{{AFX_MSG(CX64loginDlg)

	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult);
	CStatic ServerGG;
	CTabCtrl Login_Tab;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_X64LOGINDLG_H__155CDC5E_D432_4FE2_9BE8_65B2F4BCF7FF__INCLUDED_)
